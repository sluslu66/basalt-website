# Basalt Website Project

A simple static website themed around basalt stone.

## Features
- Dark volcanic design
- Responsive layout
- Clean and minimal UI

## Usage
1. Download ZIP
2. Extract files
3. Open index.html

## Author
Gudhal Production
